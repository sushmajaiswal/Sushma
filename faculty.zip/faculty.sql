-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2019 at 01:53 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty`
--

-- --------------------------------------------------------

--
-- Table structure for table `regis`
--

CREATE TABLE `regis` (
  `fid` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `experience` varchar(10) NOT NULL,
  `BCA1` varchar(10) DEFAULT NULL,
  `BCA2` varchar(10) DEFAULT NULL,
  `BCA3` varchar(10) DEFAULT NULL,
  `BCA4` varchar(10) DEFAULT NULL,
  `BCA5` varchar(10) DEFAULT NULL,
  `BCA6` varchar(10) DEFAULT NULL,
  `MCA1` varchar(10) DEFAULT NULL,
  `MCA2` varchar(10) DEFAULT NULL,
  `MCA3` varchar(10) DEFAULT NULL,
  `MCA4` varchar(10) DEFAULT NULL,
  `MCA5` varchar(10) DEFAULT NULL,
  `MCA6` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regis`
--

INSERT INTO `regis` (`fid`, `name`, `Address`, `phone_no`, `email`, `qualification`, `experience`, `BCA1`, `BCA2`, `BCA3`, `BCA4`, `BCA5`, `BCA6`, `MCA1`, `MCA2`, `MCA3`, `MCA4`, `MCA5`, `MCA6`) VALUES
('FACULTYID1', 'NIKHIL', 'BHATIA', '9304101544', 'NIKJAI15725@GMAIL.COM', 'PHD', '1', 'BCA1', 'BCA2', 'BCA3', 'BCA4', 'BCA5', 'BCA6', 'MCA1', 'MCA2', 'MCA3', '', '', ''),
('FACULTYID2', 'sushmita', 'sakchi', '8976545678', 'sus@gmail.com', 'NET QUALIFIED', '5', 'BCA1', 'BCA2', 'BCA3', 'BCA4', '', '', '', 'MCA2', 'MCA3', 'MCA4', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regis`
--
ALTER TABLE `regis`
  ADD PRIMARY KEY (`fid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
