<?php
$conn=mysqli_connect("localhost","root","","faculty");
$sql="select * from regis";
$res=mysqli_query($conn,$sql);
?>

<html>
<title>Faculty</title>
<head>
<style>
table, td, th {
  border:; ;
}

table {
  border-collapse: collapse;
  width: 70%;
  font-size: 24;
}

th {
  height: 50px;
}
</style>
</head>
<body bgcolor="teal" text="white">

<table style="margin-top:-5px;width:100%;">
<tr><th colspan="6"><img src="logo.jpg" style="margin-left:px;margin-right:px;width:100%;height:150px;">   </tr>
  <tr>
    <th colspan=" "><a href="Registration form.php">New Registration for faculty</a></th>
	<th></th>
	<th><a href="fupdate.php">Update</a></th>
	<th></th>
    <th><a href="fupdate.php">Delete</a></th>
	<th></th>
    <th><a href="fupdate.php">Search</a></th>
  </tr>


		<?php 
		echo  "<table class='table table-hover' border='1' style='width:100%;'><tr><th>Faculty ID</th><th>Faculty Name</th><th>Address</th><th>Phone.NO</th><th>Email</th><th>Qualification</th><th>experience</th></tr>";
	
			while($row=mysqli_fetch_array($res))
			{
				echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td><td>$row[6]</td></tr>";
			}


			?>
		</table>
		

</body>
</html>
