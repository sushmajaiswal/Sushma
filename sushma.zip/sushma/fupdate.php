<?php 

error_reporting(0);

if(isset($_POST['sub']))
{
	
	$fid=$_POST['f1'];
	//echo $fid;
	$name=$_POST['name'];
	//echo $name;
	$add=$_POST['add'];
	$pno=$_POST['pno'];
	$email=$_POST['email'];
	$quali=$_POST['s1'];
	$exp=$_POST['s2'];
	
    
	$conn=mysqli_connect("localhost","root","","faculty");
	 $sql1="update  regis set name='".$name."',Address='".$add."',phone_no='".$pno."',email='".$email."',
	qualification='".$quali."',experience='".$exp."',BCA1='".$_POST['n1']."',BCA2='".$_POST['n2']."',BCA3='".$_POST['n3']."',BCA4='".$_POST['n4']."',BCA5='".$_POST['n5']."',BCA6='".$_POST['n6']."',
	MCA1='".$_POST['n7']."',MCA2='".$_POST['n8']."',MCA3='".$_POST['n9']."',MCA4='".$_POST['n10']."',MCA5='".$_POST['n11']."',MCA6='".$_POST['n12']."'
	where fid='$fid'";
	mysqli_query($conn,$sql1);
	echo "<script>alert('update suucessfully');</script>";
	
}	
?>

<?php
error_reporting(0);
$conn=mysqli_connect("localhost","root","","faculty");
if(isset($_POST['s1']))
{
	$fid=$_POST['fid'];
	
	
	$conn=mysqli_connect("localhost","root","","faculty");
		$sql="select * from regis where fid='$fid'";
		$res=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($res);
		//$row[7];
		
}
?>
<?php

$conn=mysqli_connect("localhost","root","","faculty");
if(isset($_POST['s2']))
{
	$fid=$_POST['fid'];
	
	
	$conn=mysqli_connect("localhost","root","","faculty");
		$sql="delete from regis where fid='$fid'";
		$res=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($res);
		//$row[7];
		
}
?>
<html>
<head>
<title> Registration Form </title>
</head>

<script>
function del()
{
	var x=confirm("are you sure");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>

<script>
function ok()
{
	var x=confirm("are you sure");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<body bgcolor="teal" text="white">

<form method ="post" action="" >             
<pre>  <font size=5>           Faculty ID : <input type="text"  Name="fid" size="50" ><br></font>
<span> <input type="submit" value="search" name="s1" style="margin-left:20%;float:left;" ></span></form>
<form method ="post" action="" onsubmit="return del()"> 
<font size=5>             Faculty ID : <input type="text"  Name="fid" size="50" ><br></font>
<span>     <input type="submit" value="Delete" name="s2" style="margin-left:20%;float:left;" > </span> </pre> </form>
  
  <form method ="post" action="" onsubmit="return ok()" style="margin-top:-50px;"> 

<pre>            <font size=5><b><H2><u> UPDATE </u></H1></font>
<font size=5>             fid  : <input type="text"  Name="f1" size="50" value=<?php echo $row[0];?>><br></font>
<font size=5>            Name  : <input type="text"  Name="name" size="50" value=<?php echo $row[1];?>><br></font>
<font size=5>          Address : <input type="text"  Name="add" size="50" value=<?php echo $row[2];?>><br></font>
<font size=5>  Contact number  : <input type="text"  Name="pno" size="50" value=<?php echo $row[3];?>><br></font>
<font size=5>       E-mail ID  : <input type="text"  Name="email" size="50" value=<?php echo $row[4];?>><br></font>
<font size=5>    Qualification : <select name="s1" style="width:29%;">
								 <option ><?php echo $row[5];?></option>
                                 <option value="Post graduate diploma in computer application"> Post graduate diploma in computer application</option>
                                 <option value="MCA">MCA</option>
                                 <option value="PHD">PHD</option>
                                 <option value="NET QUALIFIED">NET QUALIFIED</option>
                                 </select><br>
<font size=5>       Experience : <select name="s2" style="width:29%;">
								 <option ><?php echo $row[6];?></option>
                                 <option value=1>1</option>
                                 <option value=2>2</option>
                                 <option value=3>3</option>
                                 <option value=4>4</option>
                                 <option value=5>5</option>
								 <option value=6>6</option>
                                 <option value=7>7</option>
								 <option value=8>8</option>
                                 <option value=9>9</option>
								 <option value=10>10</option>
                                 <option value=11>11</option>
                                 <option value=13>13</option>
                                 <option value=14>14</option>
                                 <option value=15>15</option>
                                 <option value=7>16</option>
                                 <option value=10>17</option>
                                 <option value="fresher">fresher</option>
</select>
</font></pre></b>
<b> classes: </b><br>
                    <input type="checkbox" name="n1" value="BCA1" id="m1" >  BCA1
                    <input type="checkbox" name="n2" value="BCA2" id="m2" >  BCA2
                    <input type="checkbox" name="n3" value="BCA3" id="m3" >  BCA3
                    <input type="checkbox" name="n4" value="BCA4" id="m4" >  BCA4
                    <input type="checkbox" name="n5" value="BCA5" id="m5" >  BCA5
                    <input type="checkbox" name="n6" value="BCA6" id="m6" >  BCA6<br>
                    
                    <input type="checkbox" name="n7" value="MCA1" id="m7"> MCA1
                    <input type="checkbox" name="n8" value="MCA2" id="m8"> MCA2
		            <input type="checkbox" name="n9" value="MCA3" id="m9"> MCA3
		            <input type="checkbox" name="n10" value="MCA4" id="m10"> MCA4
		            <input type="checkbox" name="n11" value="MCA5" id="m11"> MCA5
		            <input type="checkbox" name="n12" value="MCA6" id="m12"> MCA6 <br>
                   
    <center>  <input type="submit" value="UPDATE" name="sub">
    <input type="Reset" Value="RESET"></center>
   <a href="Faculty mains page.php">BACK</a>
   <h2 align="center"> THANKS FOR VISITING!!!</h2>
</form>
</body>
<script>
var x1="<?php echo $row[7] ?>"
var x2="<?php echo $row[8] ?>"
var x3="<?php echo $row[9] ?>"
var x4="<?php echo $row[10] ?>"
var x5="<?php echo $row[11] ?>"
var x6="<?php echo $row[12] ?>"
var x7="<?php echo $row[13] ?>"
var x8="<?php echo $row[14] ?>"
var x9="<?php echo $row[15] ?>"
var x10="<?php echo $row[16] ?>"
var x11="<?php echo $row[17] ?>"
var x12="<?php echo $row[18] ?>"

if(x1=="BCA1")
{
document.getElementById("m1").checked=true;
}
if(x2=="BCA2")
{
document.getElementById("m2").checked=true;
}
if(x3=="BCA3")
{
document.getElementById("m3").checked=true;
}
if(x4=="BCA4")
{
document.getElementById("m4").checked=true;
}
if(x5=="BCA5")
{
document.getElementById("m5").checked=true;
}
if(x6=="BCA6")
{
document.getElementById("m6").checked=true;
}
if(x7=="MCA1")
{
document.getElementById("m7").checked=true;
}
if(x8=="MCA2")
{
document.getElementById("m8").checked=true;
}
if(x9=="MCA3")
{
document.getElementById("m9").checked=true;
}
if(x10=="MCA4")
{
document.getElementById("m10").checked=true;
}
if(x11=="MCA5")
{
document.getElementById("m11").checked=true;
}
if(x12=="MCA6")
{
document.getElementById("m12").checked=true;
}

</script>
</html>