<?php 
error_reporting(0);
$c=1;
if(isset($_POST['sub']))
{
	$name=$_POST['name'];
	$add=$_POST['add'];
	$pno=$_POST['pno'];
	$email=$_POST['email'];
	$quali=$_POST['s1'];
	$exp=$_POST['s2'];
	$conn=mysqli_connect("localhost","root","","faculty");
    $sql="select * from regis";
    $res= mysqli_query($conn,$sql);
       
    while($row=mysqli_fetch_assoc($res))
    { $c=$c+1;}
     $fid="FACULTYID".(string)$c;
    
	$conn=mysqli_connect("localhost","root","","faculty");
	 $sql1="insert into regis (fid, name, Address, phone_no, email, qualification, experience,BCA1 , BCA2,BCA3,BCA4,BCA5,BCA6,MCA1,MCA2,MCA3,MCA4,MCA5,MCA6)
	 values ('".$fid."','".$name."','".$add."', '".$pno."','".$email."',
	'".$quali."','".$exp."','".$_POST['n1']."','".$_POST['n2']."','".$_POST['n3']."','".$_POST['n4']."','".$_POST['n5']."','".$_POST['n6']."',
	'".$_POST['n7']."','".$_POST['n8']."','".$_POST['n9']."','".$_POST['n10']."','".$_POST['n11']."','".$_POST['n12']."')";
	mysqli_query($conn,$sql1);
	echo "<script>alert('faculty id $fid');</script>";
	
}	
?>
<html>
<head>
<title> Registration Form </title>
</head>


<script>
function ok()
{
	var x=confirm("are you sure");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>
<body bgcolor="teal" text="white">

<pre>              
    
<form method ="post" action="" onsubmit="return ok()"> 
<font size= 5><b><H1><u> New Registration for Faculty  </u></H1></font>
   
<font size=5>            Name  : <input type="text"  Name="name" size="50" ><br></font>
<font size=5>          Address : <input type="text"  Name="add" size="50" ><br></font>
<font size=5>  Contact number  : <input type="text"  Name="pno" size="50"><br></font>
<font size=5>       E-mail ID  : <input type="text"  Name="email" size="50"/><br></font>
<font size=5>    Qualification : <select name="s1" style="width:29%;">
								<option value="others">others</option>
                                 <option value="Post graduate diploma in computer application"> Post graduate diploma in computer application</option>
                                 <option value="MCA">MCA</option>
                                 
                                 <option value="PHD">PHD</option>
                                 <option value="NET QUALIFIED">NET QUALIFIED</option>
                                 
                                 <br></select><br>
<font size=5>       Experience : <select name="s2" style="width:29%;">
                                 <option value=1>1</option>
                                 <option value=2>2</option>
                                 <option value=3>3</option>
                                 <option value=4>4</option>
                                 <option value=5>5</option>
                                 <option value=6>6</option>
                                 <option value=7>7</option>
								 <option value=8>8</option>
                                 <option value=9>9</option>
								 <option value=10>10</option>
                                 <option value=11>11</option>
                                 <option value=13>13</option>
                                 <option value=14>14</option>
                                 <option value=15>15</option>
                                 
                                 <option value="fresher">fresher</option>
</select>
</font></pre></b><br>
<b> classes alloted: </b><br>
                    <input type="checkbox" name="n1" value="BCA1" id="m1" >  BCA1
                    <input type="checkbox" name="n2" value="BCA2" id="m2" >  BCA2
                    <input type="checkbox" name="n3" value="BCA3" id="m3" >  BCA3
                    <input type="checkbox" name="n4" value="BCA4" id="m4" >  BCA4
                    <input type="checkbox" name="n5" value="BCA5" id="m5" >  BCA5
                    <input type="checkbox" name="n6" value="BCA6" id="m6" >  BCA6<br>
                    
                    <input type="checkbox" name="n7" value="MCA1"> MCA1
                    <input type="checkbox" name="n8" value="MCA2"> MCA2
		    <input type="checkbox" name="n9" value="MCA3"> MCA3
		    <input type="checkbox" name="n10" value="MCA4"> MCA4
		    <input type="checkbox" name="n11" value="MCA5"> MCA5
		    <input type="checkbox" name="n12" value="MCA6"> MCA6
                   
<br>
<center>
    <input type="submit" value="SUBMIT" name="sub" onclick="chk();">
    <input type="Reset" Value="RESET">
</center>
<a href="Faculty mains page.php">BACK</a>

    <h2 align="center"> THANKS FOR VISITING!!!</h2>

</form>
</body>
</html>